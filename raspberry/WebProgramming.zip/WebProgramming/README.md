Web-Programming
===============

Web coding project - visit: [http://mgje.github.io/webprogramming/](http://mgje.github.io/webprogramming/)


The interacative Programming Language [Processing](http://www.processing.org/) 
can be used for any kind of visualization.


Run the demo on your own Webserver
==================================

- Clone or download the repository
- compile it with [jekyll](http://jekyllrb.com/)
- rename the folder _site to webprogramming
- copy the folder webprogramming with static files to your webserver

Some ideas and code snippets are taken from [https://github.com/scottgarner/Processing-Hour-Of-Code](https://github.com/scottgarner/Processing-Hour-Of-Code)

Repository for an interactive one-hour Processing tutorial at [http://hello.processing.org/](http://hello.processing.org/).
