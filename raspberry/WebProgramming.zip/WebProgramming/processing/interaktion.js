Processing_Code="//Programmieren Sie einen neuen Pinsel.\n\nvoid setup() {\n  size(500,445);\n  background(0);\n  noStroke();\n}\n\nvoid draw() {\n\n  fill(222,221,3,9);\n  ellipse(mouseX, mouseY, 70, 70);\n}";
$("a[data-index=3]").addClass("active");
	
