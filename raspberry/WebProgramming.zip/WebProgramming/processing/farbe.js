Processing_Code='//Wie entstehen Farben?\n\nsize(500,445);\nsmooth();\nbackground(255);\nnoStroke();\n\nfill(255,0,0);\nellipse(60,60,32,32);\n\nfill(127,0,0);\nellipse(100,60,32,32);\n\nfill(255,200,200);\nellipse(140,60,32,32);\n\nfill(255,0,0);\nellipse(80,120,32,32);\n\nfill(127,0,0);\nellipse(120,120,32,32);\n\nfill(255,200,200);\nellipse(160,120,32,32);';
// $(".lessonButton").removeClass("active");
$("a[data-index=2]").addClass("active");
